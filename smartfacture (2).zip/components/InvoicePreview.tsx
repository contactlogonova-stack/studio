import React from 'react';
import { InvoiceData, PlanType } from '../types';
import { PLANS } from '../constants';

interface InvoicePreviewProps {
  data: InvoiceData;
  plan: PlanType;
}

export const InvoicePreview: React.FC<InvoicePreviewProps> = ({ data, plan }) => {
  const isFree = plan === PlanType.FREE;
  const planConfig = PLANS[plan];
  const canCustomizeLogo = planConfig.canCustomizeLogo;

  const total = data.items.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0);
  const tva = total * (data.taxRate / 100);
  const totalTTC = total + tva;
  
  // Enterprise/Pro allow color customization
  const headerColor = data.color || '#2563eb'; 

  return (
    <div className="bg-white shadow-lg border border-slate-200 p-8 rounded-sm min-h-[600px] relative flex flex-col print:shadow-none print:border-none print:w-full">
      {/* HEADER */}
      <div className="flex justify-between items-start mb-12">
        <div>
          {/* Logo Section Logic: Only show if plan allows customization AND a logo is present */}
          {canCustomizeLogo && data.logoUrl ? (
            <div className="h-16 w-16 mb-4 bg-slate-100 rounded flex items-center justify-center text-xs text-slate-400 overflow-hidden">
                <img src={data.logoUrl} alt="Logo" className="object-cover w-full h-full" />
            </div>
          ) : (
             // Default Placeholder or nothing
             <div className="h-16 w-16 mb-4 bg-slate-100 rounded flex items-center justify-center font-bold text-2xl text-slate-300">
                LOG
             </div>
          )}

          <h1 className="text-4xl font-bold text-slate-900 uppercase tracking-wide" style={{ color: plan !== PlanType.FREE ? headerColor : undefined }}>
            {data.type === 'INVOICE' ? 'FACTURE' : 'DEVIS'}
          </h1>
          <p className="text-slate-500 text-sm mt-1">#{data.id.slice(0, 8)}</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-500">Date</p>
          <p className="font-medium text-slate-900">{new Date(data.date).toLocaleDateString()}</p>
          <div className="mt-4">
             <p className="text-sm text-slate-500">Pour :</p>
             <h3 className="text-xl font-bold text-slate-900">{data.clientName || 'Nom du Client'}</h3>
          </div>
        </div>
      </div>

      {/* TABLE */}
      <div className="flex-1">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-slate-900">
              <th className="text-left py-3 text-sm font-bold text-slate-900 w-1/2">Description</th>
              <th className="text-right py-3 text-sm font-bold text-slate-900">Qté</th>
              <th className="text-right py-3 text-sm font-bold text-slate-900">Prix U.</th>
              <th className="text-right py-3 text-sm font-bold text-slate-900">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {data.items.map((item, idx) => (
              <tr key={idx}>
                <td className="py-4 text-slate-700">{item.description}</td>
                <td className="py-4 text-right text-slate-700">{item.quantity}</td>
                <td className="py-4 text-right text-slate-700">{item.unitPrice.toFixed(2)}€</td>
                <td className="py-4 text-right font-medium text-slate-900">
                  {(item.quantity * item.unitPrice).toFixed(2)}€
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* TOTALS */}
      <div className="flex justify-end mt-8 border-t border-slate-200 pt-8">
        <div className="w-1/2 space-y-3">
          <div className="flex justify-between text-slate-600">
            <span>Total HT</span>
            <span>{total.toFixed(2)}€</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>TVA ({data.taxRate}%)</span>
            <span>{tva.toFixed(2)}€</span>
          </div>
          <div className="flex justify-between text-xl font-bold text-slate-900 pt-3 border-t border-slate-100">
            <span>Total TTC</span>
            <span style={{ color: plan !== PlanType.FREE ? headerColor : undefined }}>{totalTTC.toFixed(2)}€</span>
          </div>
        </div>
      </div>

      {/* FOOTER - Forced Branding for Free */}
      <div className="mt-auto pt-12 text-center">
        {isFree ? (
          <div className="bg-slate-100 py-2 px-4 rounded-full inline-block">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest">
              Généré avec SmartFacture (Version Gratuite)
            </p>
          </div>
        ) : (
          <p className="text-xs text-slate-400">Merci de votre confiance.</p>
        )}
      </div>
    </div>
  );
};