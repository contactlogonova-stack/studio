import React from 'react';
import { PLANS, EUR_TO_FCFA } from '../constants';
import { PlanConfig, PlanType } from '../types';
import { Button } from './ui/Button';
import { Check, Star } from 'lucide-react';

interface PlanSelectorProps {
  currentPlan: PlanType;
  onSelectPlan: (plan: PlanType) => void;
  showCurrent?: boolean;
}

export const PlanSelector: React.FC<PlanSelectorProps> = ({ currentPlan, onSelectPlan, showCurrent = true }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-4">
      {Object.values(PLANS).map((plan: PlanConfig) => {
        const isCurrent = currentPlan === plan.id;
        // PlanType.PRO is now 'isPopular' based on prompt logic request, 
        // but 'Enterprise' had it in previous file. Sticking to constant definition.
        const isHighlight = plan.isPopular || plan.id === PlanType.ENTERPRISE;
        
        // Calculate FCFA
        const euroPrice = parseInt(plan.price.replace('€', ''), 10);
        const fcfaPrice = isNaN(euroPrice) ? 0 : (euroPrice * EUR_TO_FCFA).toLocaleString();

        return (
          <div 
            key={plan.id} 
            className={`
              relative flex flex-col p-6 rounded-2xl border transition-all duration-300
              ${isHighlight ? 'border-blue-500 shadow-xl scale-105 z-10 bg-white' : 'border-slate-200 bg-white shadow-sm hover:shadow-md'}
              ${isCurrent && showCurrent ? 'ring-2 ring-blue-500 ring-offset-2' : ''}
            `}
          >
            {isHighlight && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg whitespace-nowrap">
                <Star size={12} fill="currentColor" /> Recommandé
              </div>
            )}

            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-900">{plan.name}</h3>
              <div className="mt-2">
                <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-slate-900">{plan.price}</span>
                    <span className="text-slate-500 text-sm">/mois</span>
                </div>
                {euroPrice > 0 && (
                     <p className="text-sm font-medium text-blue-600 mt-1">~ {fcfaPrice} FCFA</p>
                )}
              </div>
              <p className="text-sm text-slate-500 mt-2 min-h-[40px]">{plan.description}</p>
            </div>

            <ul className="space-y-3 mb-6 flex-1">
              <li className="flex items-center gap-2 text-sm text-slate-700">
                <Check size={16} className="text-green-500 shrink-0" />
                <span>
                  {plan.maxGenerations === 'UNLIMITED' ? 'Générations illimitées' : `${plan.maxGenerations} générations/mois`}
                </span>
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-700">
                <Check size={16} className="text-green-500 shrink-0" />
                <span>{plan.templatesCount} Templates</span>
              </li>
              {plan.hasAds ? (
                 <li className="flex items-center gap-2 text-sm text-slate-400 line-through decoration-slate-400">
                   <span className="text-slate-700 no-underline">Publicités affichées</span>
                 </li>
              ) : (
                <li className="flex items-center gap-2 text-sm text-slate-700">
                   <Check size={16} className="text-green-500 shrink-0" />
                   <span>Pas de publicité</span>
                 </li>
              )}
              <li className="flex items-center gap-2 text-sm text-slate-700">
                 <Check size={16} className={plan.canCustomizeColors ? "text-green-500 shrink-0" : "text-slate-300 shrink-0"} />
                 <span className={!plan.canCustomizeColors ? "text-slate-400" : ""}>Personnalisation</span>
              </li>
            </ul>

            <Button 
              variant={isHighlight ? 'primary' : 'outline'}
              className="w-full"
              onClick={() => onSelectPlan(plan.id)}
              disabled={isCurrent && showCurrent}
            >
              {isCurrent && showCurrent ? 'Plan Actuel' : euroPrice > 0 ? 'Choisir & Payer' : 'Commencer Gratuit'}
            </Button>
          </div>
        );
      })}
    </div>
  );
};