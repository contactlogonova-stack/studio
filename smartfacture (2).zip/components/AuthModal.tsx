import React, { useState } from 'react';
import { supabase } from '../services/supabase';
import { Button } from './ui/Button';
import { X, Mail, Lock, Loader2 } from 'lucide-react';

interface AuthModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        onSuccess();
      } else {
        // Sign Up Flow
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        
        // If account created but no active session, it implies email verification is required.
        if (data.user && !data.session) {
            try {
              // Attempt to ensure verification email is sent by triggering resend explicitly
              // We use 'signup' type as it matches the initial action.
              await supabase.auth.resend({
                type: 'signup',
                email: email
              });
            } catch (resendError) {
              console.warn("Resend email warning:", resendError);
              // Ignore rate limit errors here as the initial signUp likely sent it
            }

            alert("Compte créé avec succès ! Un email de vérification a été envoyé. Veuillez cliquer sur le lien dans votre boîte mail avant de vous connecter.");
            setIsLogin(true); // Switch to login view so they can login after verifying
            return; // Do not call onSuccess() yet as they aren't logged in
        }
        
        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 z-[70] flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative p-8">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-900">
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-slate-900 mb-2">
          {isLogin ? 'Connexion' : 'Inscription'}
        </h2>
        <p className="text-slate-500 mb-6 text-sm">
          {isLogin ? 'Accédez à vos factures sauvegardées.' : 'Créez un compte pour commencer.'}
        </p>

        <form onSubmit={handleAuth} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 text-slate-400" size={18} />
              <input 
                type="email" 
                required 
                className="w-full pl-10 border border-slate-300 rounded-lg p-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="vous@exemple.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Mot de passe</label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 text-slate-400" size={18} />
              <input 
                type="password" 
                required 
                minLength={6}
                className="w-full pl-10 border border-slate-300 rounded-lg p-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded border border-red-100">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="animate-spin mr-2" size={16} />}
            {isLogin ? 'Se connecter' : "S'inscrire"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm">
          <span className="text-slate-500">
            {isLogin ? "Pas encore de compte ? " : "Déjà un compte ? "}
          </span>
          <button 
            className="text-blue-600 font-semibold hover:underline"
            onClick={() => setIsLogin(!isLogin)}
          >
            {isLogin ? "Créer un compte" : "Se connecter"}
          </button>
        </div>
      </div>
    </div>
  );
};