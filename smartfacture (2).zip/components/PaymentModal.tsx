import React, { useState } from 'react';
import { PlanConfig } from '../types';
import { createMoneyFusionPayment, getFcfaPrice } from '../services/moneyFusionService';
import { Button } from './ui/Button';
import { X, Lock, Smartphone, User } from 'lucide-react';

interface PaymentModalProps {
  plan: PlanConfig;
  onClose: () => void;
  onSuccess: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ plan, onClose, onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: ''
  });

  const priceFcfa = getFcfaPrice(plan.price);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const result = await createMoneyFusionPayment({
        customerName: formData.name,
        customerPhone: formData.phone,
        plan: plan
      });

      if (result.success && result.url) {
        if (result.url === "#simulated_redirection") {
          // Simulation flow
          alert(`[SIMULATION] Redirection vers MoneyFusion pour payer ${priceFcfa.toLocaleString()} FCFA.`);
          onSuccess();
        } else {
          // Real flow: Redirect user
          window.location.href = result.url;
        }
      } else {
        setError(result.message || "Une erreur est survenue.");
      }
    } catch (err) {
      setError("Erreur technique. Veuillez réessayer.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 z-[60] flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden relative">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative">
            <button 
                onClick={onClose}
                className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
            >
                <X size={24} />
            </button>
            <h2 className="text-xl font-bold mb-1">Paiement Sécurisé</h2>
            <p className="text-slate-300 text-sm">Via MoneyFusion (Mobile Money)</p>
        </div>

        {/* Body */}
        <div className="p-6">
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6 flex justify-between items-center">
                <div>
                    <p className="text-sm text-blue-600 font-medium">Plan {plan.name}</p>
                    <p className="text-2xl font-bold text-slate-900">{priceFcfa.toLocaleString()} FCFA</p>
                </div>
                <div className="text-right">
                   <p className="text-xs text-slate-500">Montant en Euro</p>
                   <p className="text-sm font-semibold text-slate-700">{plan.price}</p>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nom complet</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <User size={18} className="text-slate-400" />
                        </div>
                        <input 
                            required
                            type="text" 
                            className="w-full pl-10 border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2.5 border"
                            placeholder="Ex: Amadou Diallo"
                            value={formData.name}
                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Numéro Mobile Money</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Smartphone size={18} className="text-slate-400" />
                        </div>
                        <input 
                            required
                            type="tel" 
                            className="w-full pl-10 border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2.5 border"
                            placeholder="Ex: 223xxxxxxxx"
                            value={formData.phone}
                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        />
                    </div>
                    <p className="text-xs text-slate-500 mt-1">Orange Money, Moov Money, etc.</p>
                </div>

                {error && (
                    <div className="text-red-600 text-sm bg-red-50 p-2 rounded border border-red-100">
                        {error}
                    </div>
                )}

                <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700 mt-2 py-3"
                    disabled={loading}
                >
                    {loading ? 'Initialisation...' : `Payer ${priceFcfa.toLocaleString()} FCFA`}
                </Button>
                
                <div className="flex justify-center gap-2 mt-4 text-slate-400">
                    <Lock size={14} />
                    <span className="text-xs">Transactions chiffrées et sécurisées</span>
                </div>
            </form>
        </div>
      </div>
    </div>
  );
};