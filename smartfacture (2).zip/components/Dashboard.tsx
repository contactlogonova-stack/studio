import React, { useState, useEffect } from 'react';
import { AppState, InvoiceData, PlanType } from '../types';
import { PLANS, INITIAL_INVOICE_STATE } from '../constants';
import { addInvoiceToDb, upgradePlanInDb } from '../services/storage';
import { enhanceDescription, analyzeHistory } from '../services/geminiService';
import { Button } from './ui/Button';
import { AdBanner } from './AdBanner';
import { InvoicePreview } from './InvoicePreview';
import { PlanSelector } from './PlanSelector';
import { PaymentModal } from './PaymentModal';
import { AlertCircle, Lock, Wand2, RefreshCcw, LogOut, Loader2, History } from 'lucide-react';

interface DashboardProps {
  appState: AppState;
  setAppState: React.Dispatch<React.SetStateAction<AppState>>;
  refreshData: () => Promise<void>;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ appState, setAppState, refreshData, onLogout }) => {
  // Form State
  const [formData, setFormData] = useState(INITIAL_INVOICE_STATE);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [blockModal, setBlockModal] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  
  // Payment State
  const [selectedPlanForPayment, setSelectedPlanForPayment] = useState<PlanType | null>(null);

  const currentPlanConfig = PLANS[appState.plan];
  const isFree = appState.plan === PlanType.FREE;
  const limitReached = currentPlanConfig.maxGenerations !== 'UNLIMITED' && appState.usageCount >= (currentPlanConfig.maxGenerations as number);
  const nearLimit = isFree && appState.usageCount === 4;

  useEffect(() => {
    if (isFree && limitReached) {
      setBlockModal(true);
    }
  }, [appState.usageCount, isFree, limitReached]);

  // AI Analysis Effect
  useEffect(() => {
    if (appState.invoices.length > 0) {
        const total = appState.invoices.reduce((acc, inv) => {
             return acc + inv.items.reduce((s, i) => s + (i.quantity * i.unitPrice), 0);
        }, 0);
        analyzeHistory(appState.invoices.length, total).then(setAiAnalysis);
    }
  }, [appState.invoices.length]);

  const handleAiFill = async () => {
    if (!formData.description) return;
    setIsAiLoading(true);
    const enhanced = await enhanceDescription(formData.description);
    setFormData(prev => ({ ...prev, description: enhanced }));
    setIsAiLoading(false);
  };

  const handleGenerate = async (type: 'INVOICE' | 'QUOTE') => {
    if (limitReached && isFree) {
      setBlockModal(true);
      return;
    }

    setIsSaving(true);
    const newInvoice: InvoiceData = {
      id: Date.now().toString(),
      type,
      clientName: formData.clientName || 'Client Inconnu',
      items: [{
        id: '1',
        description: formData.description,
        quantity: formData.quantity,
        unitPrice: formData.unitPrice
      }],
      taxRate: formData.taxRate,
      date: new Date().toISOString(),
      color: appState.plan === PlanType.ENTERPRISE ? '#ea580c' : '#2563eb',
      planAtGeneration: appState.plan,
      logoUrl: !isFree ? 'https://picsum.photos/200' : undefined
    };

    try {
        await addInvoiceToDb(newInvoice, appState.usageCount);
        // Refresh full data from DB to ensure sync
        await refreshData();
    } catch (e) {
        alert("Erreur de sauvegarde");
    } finally {
        setIsSaving(false);
    }
  };

  const handleUpgradeRequest = (planId: PlanType) => {
    // Direct upgrade for testing flows or if we implemented free tier logic differently
    // For now we assume all paid plans go through payment
    if (planId === PlanType.FREE) {
        // Downgrade logic if needed
        setShowUpgradeModal(false);
    } else {
        setSelectedPlanForPayment(planId);
    }
  };

  const handlePaymentSuccess = async () => {
      if (selectedPlanForPayment) {
        await upgradePlanInDb(selectedPlanForPayment);
        await refreshData();
        setBlockModal(false);
        setShowUpgradeModal(false);
        setSelectedPlanForPayment(null);
      }
  };

  // --- RENDER ---

  if (blockModal) {
    return (
      <div className="fixed inset-0 bg-slate-900/80 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl relative">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock size={32} className="text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Limite atteinte 🔒</h2>
          <p className="text-slate-600 mb-8">
            Vous avez atteint la limite de 5 générations gratuites. Pour continuer à facturer, passez à la vitesse supérieure.
          </p>
          <Button 
            variant="danger" 
            size="lg" 
            className="w-full mb-3"
            onClick={() => handleUpgradeRequest(PlanType.ENTERPRISE)}
          >
            Passer à l'Entreprise (Recommandé)
          </Button>
          <Button 
             variant="outline" 
             size="sm"
             onClick={() => handleUpgradeRequest(PlanType.STARTER)}
          >
              Ou prendre le plan Starter
          </Button>
          
          {selectedPlanForPayment && (
            <PaymentModal 
                plan={PLANS[selectedPlanForPayment]}
                onClose={() => setSelectedPlanForPayment(null)}
                onSuccess={handlePaymentSuccess}
            />
          )}
        </div>
      </div>
    );
  }

  const livePreviewData: InvoiceData = {
      id: 'PREVIEW',
      type: 'INVOICE',
      clientName: formData.clientName,
      items: [{ id: '1', description: formData.description, quantity: formData.quantity, unitPrice: formData.unitPrice }],
      taxRate: formData.taxRate,
      date: new Date().toISOString(),
      planAtGeneration: appState.plan,
      color: appState.plan === PlanType.PRO || appState.plan === PlanType.ENTERPRISE ? '#0ea5e9' : undefined,
      logoUrl: !isFree ? 'https://picsum.photos/200' : undefined
  };

  return (
    <div className="min-h-screen flex flex-col relative">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">S</div>
                <span className="font-bold text-slate-900 hidden sm:inline">SmartFacture</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${isFree ? 'bg-slate-100 text-slate-600' : 'bg-blue-100 text-blue-700'}`}>
                    {currentPlanConfig.name.toUpperCase()}
                </span>
            </div>
            
            <div className="flex items-center gap-3">
                 <div className="text-xs text-right mr-2 hidden sm:block">
                    <p className="text-slate-500">Utilisation</p>
                    <p className={`font-bold ${isFree && appState.usageCount >= 4 ? 'text-red-600' : 'text-slate-900'}`}>
                        {appState.usageCount} / {currentPlanConfig.maxGenerations}
                    </p>
                 </div>
                 <Button variant="outline" size="sm" onClick={() => setShowUpgradeModal(!showUpgradeModal)}>
                    {showUpgradeModal ? 'Fermer Plans' : 'Changer Plan'}
                 </Button>
                 <button onClick={refreshData} title="Rafraichir" className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
                     <RefreshCcw size={18} />
                 </button>
                 <button onClick={onLogout} title="Déconnexion" className="p-2 text-slate-400 hover:text-red-600 transition-colors">
                     <LogOut size={18} />
                 </button>
            </div>
        </div>
      </header>

      {/* Upgrade Drawer */}
      {showUpgradeModal && (
          <div className="bg-slate-50 border-b border-slate-200 animate-in slide-in-from-top-4">
              <div className="max-w-7xl mx-auto">
                <PlanSelector currentPlan={appState.plan} onSelectPlan={handleUpgradeRequest} showCurrent={false} />
              </div>
          </div>
      )}

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Editor */}
        <div className="lg:col-span-5 space-y-6">
            
            {nearLimit && (
                <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg flex gap-3">
                    <AlertCircle className="text-orange-600 shrink-0" />
                    <div>
                        <h4 className="font-bold text-orange-800 text-sm">Attention !</h4>
                        <p className="text-orange-700 text-sm">Il ne vous reste qu'une seule génération gratuite.</p>
                    </div>
                </div>
            )}
            
            {aiAnalysis && !showUpgradeModal && (
                 <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-100 p-4 rounded-lg flex gap-3">
                    <Wand2 className="text-indigo-600 shrink-0" size={20} />
                    <p className="text-indigo-800 text-sm italic">" {aiAnalysis} "</p>
                </div>
            )}

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h2 className="text-lg font-bold text-slate-900 mb-4">Éditeur</h2>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Client</label>
                        <input 
                            type="text" 
                            className="w-full border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
                            placeholder="Entreprise ABC"
                            value={formData.clientName}
                            onChange={(e) => setFormData({...formData, clientName: e.target.value})}
                        />
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-1">
                            <label className="block text-sm font-medium text-slate-700">Prestation</label>
                            <button 
                                onClick={handleAiFill}
                                disabled={isAiLoading || !formData.description}
                                className="text-xs flex items-center gap-1 text-purple-600 hover:text-purple-700 font-medium disabled:opacity-50"
                            >
                                <Wand2 size={12} /> {isAiLoading ? '...' : 'Améliorer avec IA'}
                            </button>
                        </div>
                        <textarea 
                            className="w-full border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
                            rows={3}
                            placeholder="Dév web..."
                            value={formData.description}
                            onChange={(e) => setFormData({...formData, description: e.target.value})}
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                             <label className="block text-sm font-medium text-slate-700 mb-1">Prix Unitaire (€)</label>
                             <input 
                                type="number" 
                                className="w-full border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
                                value={formData.unitPrice}
                                onChange={(e) => setFormData({...formData, unitPrice: Number(e.target.value)})}
                             />
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-slate-700 mb-1">Quantité</label>
                             <input 
                                type="number" 
                                className="w-full border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
                                value={formData.quantity}
                                onChange={(e) => setFormData({...formData, quantity: Number(e.target.value)})}
                             />
                        </div>
                    </div>

                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">TVA (%)</label>
                        <select 
                            className="w-full border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border"
                            value={formData.taxRate}
                            onChange={(e) => setFormData({...formData, taxRate: Number(e.target.value)})}
                        >
                            <option value="0">0% (Auto-entrepreneur)</option>
                            <option value="5.5">5.5%</option>
                            <option value="10">10%</option>
                            <option value="20">20%</option>
                        </select>
                    </div>

                    <div className="pt-4 grid grid-cols-2 gap-3">
                        <Button onClick={() => handleGenerate('INVOICE')} disabled={(limitReached && isFree) || isSaving} className="w-full">
                            {isSaving ? <Loader2 className="animate-spin" /> : 'Facture'}
                        </Button>
                        <Button variant="secondary" onClick={() => handleGenerate('QUOTE')} disabled={(limitReached && isFree) || isSaving} className="w-full">
                            Devis
                        </Button>
                    </div>
                </div>
            </div>

            {/* History List */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-900 mb-4 flex justify-between items-center">
                    Historique
                    <span className="text-xs font-normal text-slate-500">
                        {currentPlanConfig.historyDays} jours conservés
                    </span>
                </h3>
                {appState.invoices.length === 0 ? (
                    <p className="text-sm text-slate-400 text-center py-4">Aucun document.</p>
                ) : (
                    <>
                        <ul className="space-y-3">
                            {appState.invoices.slice(0, 10).map((inv) => (
                                <li key={inv.id} className="flex items-center justify-between text-sm p-2 hover:bg-slate-50 rounded">
                                    <div>
                                        <span className={`font-bold ${inv.type === 'INVOICE' ? 'text-blue-600' : 'text-slate-600'}`}>
                                            {inv.type === 'INVOICE' ? 'FAC' : 'DEV'}
                                        </span>
                                        <span className="text-slate-900 ml-2">{inv.clientName}</span>
                                    </div>
                                    <span className="text-slate-400">{new Date(inv.date).toLocaleDateString()}</span>
                                </li>
                            ))}
                        </ul>
                        {appState.invoices.length > 10 && (
                            <div className="mt-4 pt-2 border-t border-slate-100">
                                <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="w-full flex items-center justify-center gap-2 text-slate-500 hover:text-slate-800"
                                    onClick={() => alert("Fonctionnalité d'historique complet à venir !")}
                                >
                                    <History size={14} /> Voir tout l'historique
                                </Button>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>

        {/* Right Column: Preview */}
        <div className="lg:col-span-7 flex flex-col">
            {isFree && <AdBanner position="top" />}
            
            <div className="flex-1 bg-slate-200/50 p-4 rounded-xl border-2 border-dashed border-slate-300 flex items-center justify-center overflow-auto">
                <div className="w-full max-w-lg origin-top scale-95 md:scale-100 transition-transform">
                   <InvoicePreview data={livePreviewData} plan={appState.plan} />
                </div>
            </div>

            {isFree && <AdBanner position="bottom" />}
        </div>

      </main>

      {/* Payment Modal for In-Dashboard Upgrades */}
      {selectedPlanForPayment && !blockModal && (
          <PaymentModal 
             plan={PLANS[selectedPlanForPayment]}
             onClose={() => setSelectedPlanForPayment(null)}
             onSuccess={handlePaymentSuccess}
          />
      )}
    </div>
  );
};