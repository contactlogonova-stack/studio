import React from 'react';

interface AdBannerProps {
  position: 'top' | 'bottom';
}

export const AdBanner: React.FC<AdBannerProps> = ({ position }) => {
  return (
    <div className={`w-full bg-yellow-100 border-y border-yellow-200 p-2 text-center text-xs font-mono text-yellow-800 flex flex-col items-center justify-center no-print ${position === 'top' ? 'mb-4' : 'mt-4'}`}>
      <span className="font-bold uppercase tracking-wider mb-1">Publicité — Version Gratuite</span>
      <div className="flex gap-4">
        <span className="bg-white/50 px-2 py-1 rounded">🚗 Achetez une voiture pas chère !</span>
        <span className="bg-white/50 px-2 py-1 rounded">💊 Pilules miracles !</span>
        <span className="bg-white/50 px-2 py-1 rounded">🎰 Casino en ligne</span>
      </div>
    </div>
  );
};