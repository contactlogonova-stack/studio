import { AppState, InvoiceData, PlanType } from '../types';
import { supabase } from './supabase';

const DEFAULT_STATE: AppState = {
  plan: PlanType.FREE,
  usageCount: 0,
  invoices: [],
};

// --- DATA FETCHING ---

export const loadUserData = async (): Promise<AppState> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return DEFAULT_STATE;

    // 1. Get Profile (Plan & Usage)
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('plan, usage_count')
      .eq('id', user.id)
      .single();

    if (profileError) {
       console.error("Error loading profile:", profileError);
       return DEFAULT_STATE;
    }

    // 2. Get Invoices
    const { data: invoicesData, error: invoicesError } = await supabase
      .from('invoices')
      .select('content')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (invoicesError) console.error("Error loading invoices:", invoicesError);

    // Unpack JSONB content
    const invoices = invoicesData ? invoicesData.map((row: any) => row.content as InvoiceData) : [];

    return {
      plan: (profile?.plan as PlanType) || PlanType.FREE,
      usageCount: profile?.usage_count || 0,
      invoices: invoices,
    };
  } catch (e) {
    console.error("System error loading data", e);
    return DEFAULT_STATE;
  }
};

// --- ACTIONS ---

export const addInvoiceToDb = async (invoice: InvoiceData, currentCount: number): Promise<AppState | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not logged in");

    // 1. Save Invoice
    const { error: invError } = await supabase.from('invoices').insert({
      id: invoice.id,
      user_id: user.id,
      content: invoice
    });
    if (invError) throw invError;

    // 2. Increment Usage
    const newCount = currentCount + 1;
    const { error: profError } = await supabase.from('profiles')
      .update({ usage_count: newCount })
      .eq('id', user.id);
    
    if (profError) throw profError;

    // Return partial state update simulation or trigger reload
    // We return full state by fetching strictly or optimistic update
    return {
       plan: PlanType.FREE, // This creates a type issue if we don't return full state. 
                            // Ideally we reload, but for optim UI:
       usageCount: newCount,
       invoices: [invoice] // Caller needs to merge
    } as any; 

  } catch (e) {
    console.error("Failed to add invoice", e);
    return null;
  }
};

export const upgradePlanInDb = async (newPlan: PlanType): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase.from('profiles')
      .update({ plan: newPlan })
      .eq('id', user.id);

    return !error;
  } catch (e) {
    console.error("Failed to upgrade plan", e);
    return false;
  }
};

export const signOutUser = async () => {
    await supabase.auth.signOut();
};