export enum PlanType {
  FREE = 'FREE',
  STARTER = 'STARTER',
  PRO = 'PRO',
  ENTERPRISE = 'ENTERPRISE',
}

export interface PlanConfig {
  id: PlanType;
  name: string;
  price: string;
  maxGenerations: number | 'UNLIMITED';
  templatesCount: number;
  hasAds: boolean;
  canCustomizeLogo: boolean;
  canCustomizeColors: boolean;
  canDuplicate: boolean;
  historyDays: number;
  description: string;
  isPopular?: boolean;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface InvoiceData {
  id: string;
  type: 'INVOICE' | 'QUOTE';
  clientName: string;
  items: InvoiceItem[];
  taxRate: number;
  date: string;
  color: string;
  logoUrl?: string;
  planAtGeneration: PlanType;
}

export interface AppState {
  plan: PlanType;
  usageCount: number;
  invoices: InvoiceData[];
}