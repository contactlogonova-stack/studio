import { PlanConfig, PlanType } from './types';

export const EUR_TO_FCFA = 655;

export const PLANS: Record<PlanType, PlanConfig> = {
  [PlanType.FREE]: {
    id: PlanType.FREE,
    name: 'Free',
    price: '0€',
    maxGenerations: 5,
    templatesCount: 1,
    hasAds: true,
    canCustomizeLogo: false,
    canCustomizeColors: false,
    canDuplicate: false,
    historyDays: 7,
    description: 'Pour tester le service.',
  },
  [PlanType.STARTER]: {
    id: PlanType.STARTER,
    name: 'Starter',
    price: '39€',
    maxGenerations: 50,
    templatesCount: 3,
    hasAds: false,
    canCustomizeLogo: true,
    canCustomizeColors: false,
    canDuplicate: false,
    historyDays: 30,
    description: 'Pour les auto-entrepreneurs.',
  },
  [PlanType.PRO]: {
    id: PlanType.PRO,
    name: 'Pro',
    price: '25€',
    maxGenerations: 500,
    templatesCount: 10,
    hasAds: false,
    canCustomizeLogo: true,
    canCustomizeColors: true,
    canDuplicate: true,
    historyDays: 365,
    description: 'Le choix malin pour freelances.',
    isPopular: true,
  },
  [PlanType.ENTERPRISE]: {
    id: PlanType.ENTERPRISE,
    name: 'Entreprise',
    price: '149€',
    maxGenerations: 'UNLIMITED',
    templatesCount: 30,
    hasAds: false,
    canCustomizeLogo: true,
    canCustomizeColors: true,
    canDuplicate: true,
    historyDays: 9999,
    description: 'Solutions illimitées pour PME.',
  },
};

export const INITIAL_INVOICE_STATE = {
  clientName: '',
  description: 'Prestation de services',
  quantity: 1,
  unitPrice: 100,
  taxRate: 20,
};