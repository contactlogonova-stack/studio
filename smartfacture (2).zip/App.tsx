import React, { useState, useEffect } from 'react';
import { loadUserData, upgradePlanInDb, signOutUser } from './services/storage';
import { AppState, PlanType } from './types';
import { PLANS } from './constants';
import { Dashboard } from './components/Dashboard';
import { PlanSelector } from './components/PlanSelector';
import { PaymentModal } from './components/PaymentModal';
import { AuthModal } from './components/AuthModal';
import { Button } from './components/ui/Button';
import { supabase } from './services/supabase';
import { Loader2 } from 'lucide-react';

type View = 'LANDING' | 'DASHBOARD';

function App() {
  const [view, setView] = useState<View>('LANDING');
  const [appState, setAppState] = useState<AppState | null>(null); // Null = loading
  const [selectedPlanForPayment, setSelectedPlanForPayment] = useState<PlanType | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [session, setSession] = useState<any>(null);

  // Initialize Auth & Data
  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) {
        loadData();
      } else {
        setAppState({
            plan: PlanType.FREE,
            usageCount: 0,
            invoices: []
        }); // Default state for landing
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        loadData();
        setView('DASHBOARD');
        setShowAuthModal(false);
      } else {
        setView('LANDING');
        setAppState({ plan: PlanType.FREE, usageCount: 0, invoices: [] });
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadData = async () => {
    const data = await loadUserData();
    setAppState(data);
  };

  const handleStart = () => {
    if (session) {
      setView('DASHBOARD');
    } else {
      setShowAuthModal(true);
    }
  };

  const handleLogout = async () => {
    await signOutUser();
    setView('LANDING');
  };

  const handlePlanSelection = (planId: PlanType) => {
    if (!session) {
      setShowAuthModal(true);
      return;
    }

    if (planId === PlanType.FREE) {
        // Just move to dashboard
        setView('DASHBOARD');
    } else {
        setSelectedPlanForPayment(planId);
    }
  };

  const handlePaymentSuccess = async () => {
      if (selectedPlanForPayment) {
          // Update Plan in Supabase
          const success = await upgradePlanInDb(selectedPlanForPayment);
          if (success && appState) {
             setAppState({ ...appState, plan: selectedPlanForPayment });
          }
          setSelectedPlanForPayment(null);
          setView('DASHBOARD');
      }
  };

  if (!appState) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
            <Loader2 className="animate-spin text-blue-600" size={48} />
        </div>
    );
  }

  if (view === 'DASHBOARD' && session) {
    return (
      <Dashboard 
        appState={appState} 
        setAppState={setAppState as any} // Typing hack due to async nature transition
        refreshData={loadData} // New prop to re-fetch
        onLogout={handleLogout}
      />
    );
  }

  // Landing Page Render
  return (
    <div className="min-h-screen bg-slate-50 relative">
      <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">S</div>
            <span className="font-bold text-2xl text-slate-900 tracking-tight">SmartFacture</span>
        </div>
        <div className="flex gap-4">
            <Button variant="outline" onClick={() => setShowAuthModal(true)}>Connexion</Button>
            <Button onClick={handleStart}>Commencer</Button>
        </div>
      </nav>

      <header className="max-w-4xl mx-auto text-center pt-20 pb-16 px-6">
        <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 leading-tight">
          Facturez plus vite,<br/> <span className="text-blue-600">soyez payé plus tôt.</span>
        </h1>
        <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
          L'outil de facturation le plus simple pour freelances et PME en Afrique. 
          Générez des documents professionnels en quelques secondes. Sauvegardé dans le cloud.
        </p>
        <Button size="lg" className="rounded-full px-8 shadow-xl shadow-blue-200" onClick={handleStart}>
            Créer ma première facture &rarr;
        </Button>
      </header>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">Des tarifs adaptés à votre croissance</h2>
        <PlanSelector currentPlan={PlanType.FREE} onSelectPlan={handlePlanSelection} showCurrent={false} />
      </section>

      <footer className="bg-slate-900 text-slate-400 py-12 text-center">
        <p>&copy; 2024 SmartFacture. Intégration Supabase & MoneyFusion.</p>
      </footer>

      {/* Payment Modal */}
      {selectedPlanForPayment && (
          <PaymentModal 
             plan={PLANS[selectedPlanForPayment]}
             onClose={() => setSelectedPlanForPayment(null)}
             onSuccess={handlePaymentSuccess}
          />
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal 
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => setShowAuthModal(false)} 
        />
      )}
    </div>
  );
}

export default App;