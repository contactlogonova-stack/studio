import { PlanConfig } from '../types';
import { EUR_TO_FCFA } from '../constants';

// 🔒 SECURITY: NEVER COMMIT REAL KEYS TO PUBLIC REPOSITORIES
// 🔒 Placeholders for MoneyFusion integration
// Use a syntactically valid URL to prevent runtime parsing errors
const MONEY_FUSION_API_URL = "https://api.moneyfusion.net/paiement/initier"; 
// const MONEY_FUSION_API_KEY = "YOUR_API_KEY"; // Si nécessaire dans les headers

export interface PaymentDetails {
  customerName: string;
  customerPhone: string; // Format: 223xxxxxxxx (Mali) or local format
  plan: PlanConfig;
}

/**
 * Calculates the price in FCFA based on the fixed rate.
 */
export const getFcfaPrice = (priceStr: string): number => {
  const euro = parseInt(priceStr.replace('€', ''), 10);
  if (isNaN(euro)) return 0;
  return euro * EUR_TO_FCFA;
};

/**
 * Initiates a payment session with MoneyFusion.
 * 
 * Documentation:
 * POST YOUR_API_URL
 * Payload: { totalPrice, article, numeroSend, nomclient, personal_Info, return_url, webhook_url }
 */
export const createMoneyFusionPayment = async (details: PaymentDetails): Promise<{ success: boolean; url?: string; message?: string }> => {
  const priceFcfa = getFcfaPrice(details.plan.price);
  
  // Formatage basique du numéro: Suppression des espaces et ajout de l'indicatif 223 (Mali) si manquant (8 chiffres)
  let formattedPhone = details.customerPhone.replace(/\s+/g, '').replace(/^\+/, '');
  if (/^\d{8}$/.test(formattedPhone)) {
      formattedPhone = `223${formattedPhone}`;
  }
  
  // Construct the payload strictly according to documentation
  const payload = {
    totalPrice: priceFcfa,
    article: [
      { [`SmartFacture ${details.plan.name.toUpperCase()}`]: priceFcfa }
    ],
    numeroSend: formattedPhone, 
    nomclient: details.customerName,
    personal_Info: [
      {
        // TODO: INJECTION ID UTILISATEUR ICI
        // Remplacer "LOCAL_USER_ID" par l'ID unique de l'utilisateur connecté (via Supabase auth par exemple)
        // pour permettre la réconciliation automatique via le webhook.
        userId: "LOCAL_USER_ID", 
        plan: details.plan.id
      }
    ],
    return_url: window.location.origin, // Redirect back to app after success
    webhook_url: "https://your-domain.com/api/webhooks/moneyfusion" // 🔒 À REMPLIR: URL de votre webhook serveur
  };

  console.log("💰 MoneyFusion Payload Prepared:", payload);

  try {
    // ⚠️ Simulation logic for frontend-only prototype
    // We check against the placeholder URL to trigger simulation
    if (MONEY_FUSION_API_URL === "https://api.moneyfusion.net/paiement/initier") {
      console.warn("⚠️ MoneyFusion API URL is set to default. Simulating API call...");
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Return a simulated success response structure
      return {
        success: true,
        url: "#simulated_redirection",
        message: "Simulation: Paiement initié avec succès"
      };
    }

    // Real API Call Implementation
    const response = await fetch(MONEY_FUSION_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // 'Authorization': `Bearer ${MONEY_FUSION_API_KEY}` // Uncomment if auth header required
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`MoneyFusion API Error: ${response.statusText}`);
    }

    const data = await response.json();

    // Check response structure: { statut: true, url: "..." }
    if (data.statut && data.url) {
      return { success: true, url: data.url };
    } else {
      return { success: false, message: "Réponse invalide du fournisseur de paiement" };
    }

  } catch (error) {
    console.error("Payment Error:", error);
    return { success: false, message: "Erreur de connexion au service de paiement." };
  }
};

/**
 * Checks the status of a payment using the token.
 * GET https://www.pay.moneyfusion.net/paiementNotif/<TOKEN>
 */
export const checkPaymentStatus = async (token: string): Promise<string> => {
  const verificationUrl = `https://www.pay.moneyfusion.net/paiementNotif/${token}`;
  
  try {
    console.log(`Checking payment status for token: ${token} at ${verificationUrl}`);
    // const response = await fetch(verificationUrl);
    // const data = await response.json();
    // return data.statut; // Adapt based on actual response shape
    return "PENDING"; 
  } catch (error) {
    console.error("Verification Error:", error);
    return "ERROR";
  }
};