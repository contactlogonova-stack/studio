import { GoogleGenAI } from "@google/genai";

const getAiClient = () => {
  if (!process.env.API_KEY) return null;
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const enhanceDescription = async (keywords: string): Promise<string> => {
  const ai = getAiClient();
  if (!ai) {
    console.warn("API Key not found, returning mock data");
    return `[Simulation AI] Service professionnel pour: ${keywords}`;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Génère une description de ligne de facture professionnelle et concise (max 15 mots) pour ce service : "${keywords}". Ne mets pas de guillemets.`,
    });
    return response.text || keywords;
  } catch (error) {
    console.error("Gemini Error:", error);
    return keywords;
  }
};

export const analyzeHistory = async (invoiceCount: number, totalAmount: number): Promise<string> => {
    const ai = getAiClient();
    if (!ai) return "Excellente progression ! Continuez ainsi.";

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Agis comme un coach business. J'ai généré ${invoiceCount} factures pour un total de ${totalAmount}€. Donne-moi un conseil d'une phrase courte et motivante pour augmenter mon chiffre d'affaires.`,
        });
        return response.text || "Continuez votre excellent travail !";
    } catch (error) {
        return "Analysez vos données pour optimiser vos revenus.";
    }
};